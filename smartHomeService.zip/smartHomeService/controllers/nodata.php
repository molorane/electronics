<?php


class nodata extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
	}

	function index(){
		$this->view->title = "404 Error";
		$this->view->page = "Data Not found";
		$this->view->msg = "Data associated with the device selected was not found.";
		$this->view->errorCode = "Resource Forbidden";
		$this->view->render('nodata/index',false);
	}
}
