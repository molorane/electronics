<?php


class forbidden extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
	}

	function index(){
		$this->view->title = "403 Forbidden error";
		$this->view->page = "Resource Not Authorized";
		$this->view->msg = "Resource content you are trying to view is forbidden!";
		$this->view->errorCode = "Resource Forbidden";
		$this->view->render('forbidden/index',false);
	}
}
