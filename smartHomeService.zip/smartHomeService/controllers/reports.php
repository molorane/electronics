<?php
	class reports extends maincontroller{

		function __construct(){
			parent::__construct();
			$this->isLoggedIn();
			$this->LoggedInUser = session::get('UserName');
			$this->view->controller = "connected_device";
			self::fusionChartScripts();
			self::pnotifyScripts();
		}

	function index(){
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/reports/live/js/getAppStats.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
					
		$this->view->title = "Smart Home";
		$this->view->page = "Reporting";
		$this->view->action = "reports";
		$this->view->render('reports/live/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	// GetReportData
	function GetReportData(){
		
		$ddlCategory = $_POST['ddlCategory'];
		
		echo $this->model->GetReportData($ddlCategory);
		die;
	}
}
