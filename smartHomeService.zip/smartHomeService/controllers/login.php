<?php
	class login extends maincontroller{
		
		function __construct(){
			parent::__construct();
		}

		function index(){
			$txtUsername = $_POST['txtUsername'];
			$pswPassword = $_POST['pswPassword'];
			$this->model->login($txtUsername,$pswPassword);
			die;
		}
	}
?>
