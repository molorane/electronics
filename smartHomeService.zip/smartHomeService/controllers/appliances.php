<?php
	class appliances extends maincontroller{
		
		function __construct(){
			parent::__construct();
		}

	function applianceCategories(){
		echo $this->model->applianceCategories();
	}
	
	function applianceDevices(){
		$appID = $_POST['appID'];
		echo $this->AllDevices($appID);
	}
	
	function lightbulbs(){
		echo $this->AllDevices(1);
	}
	
	// Get all devices with device_id =device_id 
	function AllDevices($app_id){
		return $this->model->AllDevices($app_id); die;
	}
	
	// Get allConnectedBulbs
	function allConnectedBulbs(){
		echo $this->model->allConnectedBulbs(); die;
	}
	
	function allPIRBulbs(){
		$pir_id = $_POST['pir_id'];
		echo $this->model->allPIRBulbs($pir_id); die;
	}
	
	function addPIRBulb(){
		$pir_id = $_POST['pir_id'];
		$conn_d_id = $_POST['conn_d_id'];
		echo $this->model->addPIRBulb($pir_id ,$conn_d_id); die;
	}
	
	function deletePIRBulb(){
		$conn_d_id = $_POST['conn_d_id'];
		$pir_id = $_POST['pir_id'];
		echo $this->model->deletePIRBulb($conn_d_id, $pir_id); die;
	}
}
