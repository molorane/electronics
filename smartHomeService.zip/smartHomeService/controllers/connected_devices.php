<?php

class connected_devices extends maincontroller{

	function __construct(){
		parent::__construct();
	}
	
	// Add Appliance
	function AllConnectedDevices(){
		echo $this->model->AllConnectedDevices();
		die;
	}
	
	// get Connected Device
	function getConnectedDevice(){
		$conn_device_id = $_POST['device_id'];
		echo $this->model->getConnectedDevice($conn_device_id);
		die;
	}
	
	// get Device
	function getDevice($conn_device_id){
		return $this->model->getConnectedDevice($conn_device_id);
	}
	
	// get DeviceActivity
	function getDeviceActivity(){
		$conn_device_id = $_POST['device_id'];
		echo $this->model->getDeviceActivity($conn_device_id);
		die;
	}
	
	// onStatusChange
	function onStatusChange(){
		$conn_d_id = $_POST['device_id'];
		$dstatus = $_POST['dstatus'];
		$userName = $_POST['userName'];
		$this->model->onStatusChange($userName, $conn_d_id, $dstatus);
		die;
	}
	
	// onModeChange
	function onModeChange(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$dstatus = $_POST['dstatus'];
		$userName = $_POST['userName'];
		$this->model->onModeChange($userName, $conn_device_id, $device_type, $dstatus);
		die;
	}
	
	// setAutoOnTime
	function setAutoOnTime(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$auto_time = $_POST['auto_time'];
		$userName = $_POST['userName'];
		$this->model->setAutoOnTime($userName, $conn_device_id, $device_type, $auto_time);
		die;
	}
	
	// setAutoOffTime
	function setAutoOffTime(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$auto_time = $_POST['auto_time'];
		$userName = $_POST['userName'];
		$this->model->setAutoOffTime($userName, $conn_device_id, $device_type, $auto_time);
		die;
	}

	
	/**
	 *  Macros Commands
	 *	macrosStatus
	 * @param array(ints) $device_ids  is a list of all devices to either turn on / off.
	 */
	 
	function macrosTurnOn(){
		$device_ids = $_POST['device_ids'];
		$userName = $_POST['userName'];
		echo $this->model->macrosTurnOn($userName,$device_ids);
		die;
	}
	
	function macrosTurnOff(){
		$device_ids = $_POST['device_ids'];
		$userName = $_POST['userName'];
		echo $this->model->macrosTurnOff($userName,$device_ids);
		die;
	}
}
