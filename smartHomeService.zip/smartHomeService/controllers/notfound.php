<?php


class notfound extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
	}

	function index(){
		$this->view->title = "Error 404";
		$this->view->page = "Resource Not Found";
		$this->view->msg = "Resource content you are trying to view not found!";
		$this->view->errorCode = "Resource Not Found";
		$this->view->render('notfound/index',false);
	}
}
