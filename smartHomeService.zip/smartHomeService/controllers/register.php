<?php
	class register extends maincontroller{
		
		function __construct(){
			parent::__construct();
		}

		function index(){
			$txtUsername = $_POST['txtUsernameSignup'];
			$txtFirstName = $_POST['txtFirstNameSignup'];
			$txtLastName = $_POST['txtLastNameSignup'];
			$txtEmail = $_POST['txtEmailSignup'];
			$txtTelephone = $_POST['txtTelephoneSignup'];
			$pswPassword = $_POST['pswPasswordSignup'];
			$pswPasswordConfirm = $_POST['pswPasswordConfirmSignup'];
			$this->model->register($txtUsername,$txtFirstName,$txtLastName,$txtEmail,$txtTelephone,
									$pswPassword,$pswPasswordConfirm);
			die;
		}
	}
?>
