<?php
	class periodic_reports extends maincontroller{

		function __construct(){
			parent::__construct();
			$this->isLoggedIn();
			$this->LoggedInUser = session::get('UserName');
			$this->view->controller = "connected_device";
			self::fusionChartScripts();
			self::pnotifyScripts();
		}

	function index(){
		
		array_push($this->view->css,
							CSS_DIRECTORY.'bootstrap-datetimepicker.min.css');
							
		array_push($this->view->js,
					JS_DIRECTORY.'datepicker.js');
							
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/reports/periodic/js/periodic.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
					
		$this->view->title = "Smart Home";
		$this->view->page = "Periodic Reporting";
		$this->view->action = "reports";
		$this->view->render('reports/periodic/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	function todayElectricyCost(){
		echo $this->model->todayElectricyCost(); die;
	}
	
	function weekElectricyCost(){
		$order = $_POST['order'];
		echo $this->model->weekElectricyCost($order); die;
	}
	
	function monthElectricyCost(){
		$order = 1;
		echo $this->model->monthElectricyCost($order); die;
	}
	
	function quarterElectricyCost(){
		$order = $_POST['order'];
		echo $this->model->quarterElectricyCost($order); die;
	}
	
	function yearlyElectricyCost(){
		$order = $_POST['order'];
		echo $this->model->yearlyElectricyCost($order); die;
	}
	
	function getElectricyCostWithRange(){
		$startDate = $_POST['startDate'];
		$endDate = $_POST['endDate'];
		echo $this->model->getElectricyCostWithRange($startDate, $endDate); die;
	}
}
