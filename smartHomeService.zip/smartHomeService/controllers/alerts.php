<?php
	class alerts extends maincontroller{

		function __construct(){
			parent::__construct();
			$this->isLoggedIn();
			$this->LoggedInUser = session::get('UserName');
			self::pnotifyScripts();
		}

	function index(){
		
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/home/js/report.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
									
		$this->view->title = "Smart Home";
		$this->view->page = "Home";
		$this->view->action = "home";
		$this->view->render('home/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	

	function state($parameters){
		
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/alerts/state/js/state.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
		
		if(isset($parameters['al_id'])){
			$this->view->title = "Smart Home";
			$this->view->page = "Alerts";
			$this->view->action = "Alerts";
			$this->view->render('alerts/state/index');
		}else{
			$this->invalidParameters();
		}
	}
	
	function usage($parameters){
		
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/alerts/usage/js/usage.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
		
		if(isset($parameters['al_id'])){
			$this->view->title = "Smart Home";
			$this->view->page = "Alerts";
			$this->view->action = "Alerts";
			$this->view->render('alerts/usage/index');
		}else{
			$this->invalidParameters();
		}
	}
	
	function getStateAlerts(){
		echo $this->model->getStateAlerts(); die;
	}
	
	function getStateAlert(){
		$al_id = $_POST['al_id'];
		echo $this->model->getStateAlert($al_id); die;
	}
	
	function getUsageAlerts(){
		echo $this->model->getUsageAlerts(); die;
	}
	
	function getUsageAlert(){
		$al_id = $_POST['al_id'];
		echo $this->model->getUsageAlert($al_id); die;
	}
	
	function alertSeen(){
		$al_id = $_POST['al_id'];
		echo $this->model->alertSeen($al_id); die;
	}
	
	function getDevices(){
		$devices = $_POST['devices'];
		echo $this->model->getDevices($devices); die;
	}
}
