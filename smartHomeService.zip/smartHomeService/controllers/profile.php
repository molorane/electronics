<?php


class profile extends maincontroller{

	function __construct(){
		parent::__construct();
	}

	function index(){				
		$txtUsername = $_POST['txtUsername'];
		echo $this->model->getProfile($txtUsername);
		die;
	}
	
	function updateProfile(){				
		$txtUsername = $_POST['txtUsername'];
		$txtFirstName = $_POST['txtFirstName'];
		$txtLastName = $_POST['txtLastName'];
		$this->model->updateProfile($txtUsername, $txtFirstName,$txtLastName);
		die;
	}
	
	function changePassword(){				
		$txtUsername = $_POST['txtUsername'];
		$OPassword = $_POST['pswOPassword'];
		$NPassword = $_POST['pswNPassword'];
		$CPassword = $_POST['pswCPassword'];
		$this->model->changePassword($txtUsername, $OPassword,$NPassword, $CPassword);
		die;
	}
}
