<?php
	
	include 'config/constants.php';
	include 'config/database.php';

	define('PROJECT_DIRECTORY', __DIR__ );
	
	$pDirectory = str_replace('\\', '/', PROJECT_DIRECTORY).'/';
	
	$domain = explode('/', $_SERVER['REQUEST_URI']);
	
	define('CSS_DIRECTORY',"http://$_SERVER[HTTP_HOST]/{$domain[1]}/assets/css/");
	define('JS_DIRECTORY',"http://$_SERVER[HTTP_HOST]/{$domain[1]}/assets/js/");
	define('IMG_DIRECTORY',"http://$_SERVER[HTTP_HOST]/{$domain[1]}/assets/img/");
	define('PROFILE_DIRECTORY',"http://$_SERVER[HTTP_HOST]/{$domain[1]}/assets/profiles/");
	define('URL_DIRECTORY',"http://$_SERVER[HTTP_HOST]/{$domain[1]}/");
	
	
	spl_autoload_register(function ($class) {

		$sources = array(PROJECT_DIRECTORY."/libs/{$class}.php",
										 PROJECT_DIRECTORY."/models/{$class}.php",
								 		 PROJECT_DIRECTORY."/models/entities/{$class}.php",
										 PROJECT_DIRECTORY."/controllers/{$class}.php");

	    foreach ($sources as $source) {
	        if (file_exists($source)) {
	            require_once $source;
	        }
	    }
	});


	try{
		$app = new bootstrap();
	}catch (Exception $e) {
	    echo $e->getMessage();
	}
