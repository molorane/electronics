<?php

abstract class model{

	public $LoggedInUserID;

	function __construct(){
		try{
			$this->conn = new database();
			$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		}catch(PDOException $e){
		    echo "Connect to db: ".$e->getMessage();
		}
	}

	public function index($UserName){
		try{
			$sql = 'SELECT si.surname,si.first_name,u.Email,si.profile
							FROM tbl_user_info si
							LEFT JOIN tbl_users u
							ON si.userName = u.userName
							WHERE si.userName = ?';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(1, $UserName, PDO::PARAM_STR);
			$sth->execute();
			return $sth->fetch();
		}catch(PDOException $e){
		    echo "get user profile: ".$e->getMessage();
		}
	}
	
	/******************************************************
	* Alert section
	*******************************************************/
	function countAlerts(){
		try{
			$query = "CALL countAlerts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return $sth->fetch();
		}catch(PDOException $e){
		    self::GenericResponse(0,"countAlerts: ".$e->getMessage());
		}
	}
	
	function getStateAlerts(){
		try{
			$query = "CALL getStateAlerts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getStateAlerts: ".$e->getMessage());
		}
	}
	
	function getStateAlert($al_id){
		try{
			$query = "CALL getStateAlert(:_al_id)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':_al_id', $al_id, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getStateAlert: ".$e->getMessage());
		}
	}
	
	function getUsageAlerts(){
		try{
			$query = "CALL getUsageAlerts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getUsageAlerts: ".$e->getMessage());
		}
	}
	
	function getUsageAlert($al_id){
		try{
			$query = "CALL getUsageAlert(:_al_id)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':_al_id', $al_id, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getUsageAlert: ".$e->getMessage());
		}
	}
	
	function getDevices($devices){
		try{
			$arr = array();
			
			$tokens = strtok($devices,',');
			
			while($tokens != false){
				
				$query = "SELECT cd.conn_d_id,cd.appID,cd.connID,m.mode,a.appliance,l.location,cd.locationID,cd.device_name,cd.watts,b.microController,CONCAT('GPIO',cd.PIN) as PIN,
								cd.date_added,cd.state,cd.modeID,cd.auto_time_on,cd.auto_time_off,p.connPort,v.level, v.levelID
								FROM tbl_connected_devices cd
								JOIN tbl_appliances a
								ON cd.appID = a.appID
								JOIN tbl_board b
								ON cd.connID = b.connID
								JOIN tbl_mode m
								ON cd.modeID = m.modeID
								JOIN tbl_location l
								ON cd.locationID = l.locationID
								JOIN tbl_ports p
								ON cd.connPortID = p.connPortID
								JOIN tbl_level v
								ON cd.levelID = v.levelID
								WHERE cd.conn_d_id = :conn_d_id";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(":conn_d_id", $tokens);
				$sth->execute();
				array_push($arr, $sth->fetch());
				$tokens = strtok(',');
			}
			return json_encode($arr);
		}catch(PDOException $e){
		    self::GenericResponse(0,"getAlerts: ".$e->getMessage());
		}
	}
	
	function getConsumptionAlerts(){
		try{
			$query = "CALL getConsumptionAlerts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getConsumptionAlerts: ".$e->getMessage());
		}
	}
	
	//Get Consumption
	function GetApp(){
		try{
			$query = "CALL getApp()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetApp: ".$e->getMessage());
		}
	}
	
	public function gettotalUsage(){
		try{
			$sql = 'CALL totalUsage()';
			$sth = $this->conn->prepare($sql);
			$sth->execute();
			return $sth->fetch();
		}catch(PDOException $e){
			self::GenericResponse(0,"totalUsageProc: ".$e->getMessage());
		}
	}
	
	public function gettotalDevices(){
		try{
			$sql = 'CALL totalDevices()';
			$sth = $this->conn->prepare($sql);
			$sth->execute();
			return $sth->fetch();
		}catch(PDOException $e){
			self::GenericResponse(0,"totalDevicesProc: ".$e->getMessage());
		}
	}
	
	public function GetAllBoards(){
		$board = new board();
		return $board->AllBoard();
	}

	// Send back response to the calling client
	function GenericResponse($status,$message, $lastInsertId = 0){
		$response["success"] = $status;
		$response["message"] = $message;
		$response["lastInsertId"] = $lastInsertId;
		echo json_encode($response);
	}


	// Return response
	function returnResponse($status,$message){
		$response["success"] = $status;
		$response["message"] = $message;
		return $response;
	}
	
	//Get user uploads
	function UserUploads($id_no){
		$applicationdocument = new applicationdocument();
		return $applicationdocument->GetApplicationDocumentByPersonID($id_no);
	}
	
	function generateRandomString($length = 10) {
		return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
	}
}
