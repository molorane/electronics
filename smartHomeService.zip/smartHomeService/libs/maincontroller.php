<?php

abstract class maincontroller{

	public $LoggedInUser = null;

	function __construct(){
		
		$this->view = new view();
		
		$this->view->css = array(
							CSS_DIRECTORY.'bootstrap.min.css?v=1.1',
							CSS_DIRECTORY.'font-awesome.css?v=1.1',
							CSS_DIRECTORY.'jquery-ui.css?v=1.1',
							CSS_DIRECTORY.'animate.min.css?v=1.1',
							CSS_DIRECTORY.'custom.css?v=1.1',
							CSS_DIRECTORY.'icheck/flat/green.css?v=1.1',
							CSS_DIRECTORY.'css/switchery/switchery.min.css?v=1.1',
							CSS_DIRECTORY.'dataTables.bootstrap.css?v=1.1');
							
		$this->view->js = array(
							JS_DIRECTORY.'bootstrap.min.js?v=1.1',
							JS_DIRECTORY.'jquery-ui.min.js?v=1.1',
							JS_DIRECTORY.'nicescroll/jquery.nicescroll.min.js?v=1.1',
							JS_DIRECTORY.'progressbar/bootstrap-progressbar.min.js?v=1.1',
							JS_DIRECTORY.'icheck/icheck.min.js?v=1.1',
							JS_DIRECTORY.'switchery/switchery.min.js?v=1.1',
							JS_DIRECTORY.'moment/moment.min.js?v=1.1',
							JS_DIRECTORY.'custom.js?v=1.1');
	}
	
	function pnotifyScripts(){
		array_push($this->view->js,
							JS_DIRECTORY.'notify/pnotify.core.js?v=1.1',
							JS_DIRECTORY.'notify/pnotify.buttons.js?v=1.1',
							JS_DIRECTORY.'notify/pnotify.nonblock.js?v=1.1',
							JS_DIRECTORY.'notify/sticky.js?v=1.1',
							JS_DIRECTORY.'customTabbedNotifications.js?v=1.1');
	}
	
	
	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	function dataTableScripts(){
		array_push($this->view->js,
					JS_DIRECTORY.'jquery.dataTables.min.js',
					JS_DIRECTORY.'dataTables.bootstrap.min.js',
					JS_DIRECTORY.'dataTables.responsive.js',
					JS_DIRECTORY.'make_table_responsive.js');
	}
	
	function fusionChartScripts(){
		array_push($this->view->js,
			JS_DIRECTORY.'fusionCharts/fusioncharts.js?v=1.1',
			JS_DIRECTORY.'fusionCharts/jquery-fusioncharts.js?v=1.1',
			JS_DIRECTORY.'fusionCharts/themes/fusioncharts.theme.fint.js?v=1.1');
	}

	//Load LoggedInUserdata
	function LoggedInUserData(){
		$data = $this->model->index($this->LoggedInUser);
		$this->view->UserID = $this->LoggedInUser;
		$this->view->UserData = $data;
		$this->view->userRole = session::get('UserRole');
	}
	
	function GetApp(){
		return $this->model->GetApp();
	}
	
	function totalDevices(){
		return $this->model->gettotalDevices();
	}
	
	function totalUsage(){
		return $this->model->gettotalUsage();
	}

	function logout(){
		session::destroy();
		header('location: '.URL_DIRECTORY.'login');
		die;
	}
	
	function getNotifications(){
		$this->view->alerts = $this->model->countAlerts();
		$this->view->stateAlerts = self::getStateAlerts();
		$this->view->usageAlerts = self::getUsageAlerts();
	}
	
	function getStateAlerts(){
		return json_decode($this->model->getStateAlerts(),true);
	}
	
	function getUsageAlerts(){
		return json_decode($this->model->getUsageAlerts(),true);
	}
	
	function getConsumptionAlerts(){
		return json_decode($this->model->getConsumptionAlerts(),true);
	}
	
	// Send back response to the calling client
	function GenericResponse($status,$message, $lastInsertId = 0){
		$response["success"] = $status;
		$response["message"] = $message;
		$response["lastInsertId"] = $lastInsertId;
		echo json_encode($response);
	}


	// Return response
	function returnResponse($status,$message){
		$response["success"] = $status;
		$response["message"] = $message;
		return $response;
	}
	
	function generateRandomString($length = 10) {
		return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
	}

	/*
	 * Check if user logged In,
	 * If not logged In redirect to login page.
	*/
	public function isLoggedIn(){
		session::init();
		$logged = session::get('LoggedIn');

		if($logged == false){
			session::destroy();
			header('location: '.URL_DIRECTORY.'login');
			die;
		}
	}

	/*
	 * Check if user loggedIn,
	 * if not logged in, deny user access of resource or service
	*/
	public function userLoggedIn(){
		session::init();
		$logged = session::get('LoggedIn');

		if($logged == false){
			$this->GenericResponse(0,'Sorry! You do not have right to access the required content or service!');
			die;
		}
	}

	/*
	 * Check if user is authorised access to a resource or service,
	 * if not deny access, otherwise allow acces
	*/
	public function isUserAllowed($user,$roles){

		$allowed = false;
		foreach ($roles as $role) {
			if ($user == $role) {
				$allowed = true;
				break;
			}
		}

		if(!$allowed){
			$this->forbidden();
		}
	}

	public function isAuthorised($user,$roles){

		foreach ($roles as $role) {
			if ($user == $role) {
				return true;
			}
		}
		return false;
	}

	public function loadModel($name) {

		$path = 'models/'.strtolower($name).'_model.php';

		if(file_exists($path)){
			require $path;

			$modelName = strtolower($name).'_model';
			$this->model = new $modelName();

			if(isset($this) && strtolower($name) != 'notfound'
						&& strtolower($name) != 'forbidden'
						&& strtolower($name) != 'invalidparameters'
						&& strtolower($name) != 'login'
						&& strtolower($name) != 'studentregister'
						&& strtolower($name) != 'data'
						&& strtolower($name) != 'contractexpired'
						&& strtolower($name) != 'forgotpassword'){
					
				$this->view->app = json_decode(self::GetApp(),true);
				$this->LoggedInUserData();
				$this->view->usage = self::totalUsage();
				$this->view->appliances = self::totalDevices();
				$this->getNotifications();
			}
		}else{
			echo 'Controller <b>'.$name.'</b> does not have a corresponding model class!';
			die;
		}
	}

	function nodata(){
		$controller = new nodata();
		$controller->loadModel('nodata');
		$controller->index();
		die;
	}
	
	function notFound(){
		$controller = new notfound();
		$controller->loadModel('notFound');
		$controller->index();
		die;
	}

	function forbidden(){
		$controller = new forbidden();
		$controller->loadModel('forbidden');
		$controller->index();
		die;
	}

	function invalidParameters(){
		$controller = new invalidparameters();
		$controller->loadModel('invalidParameters');
		$controller->index();
		die;
	}

	function isArrayAllSet($array) {
	    foreach($array as $key => $val) {
	        if (empty($val))
	            return false;
	    }
	    return true;
	}

	
	function unsetSessions(){
		$requiredSessionVar = array('x','y');
		foreach($_SESSION as $key => $value) {
		    if(!in_array($key, $requiredSessionVar)) {
		        unset($_SESSION[$key]);
		    }
		}
	}

	function unsetExcept($arraySessions,$keys) {
	    foreach ($arraySessions as $key => $value){
	        if(!in_array($key, $keys)){
	            unset($arraySessions[$key]);
	        }
	    }
	}
}
