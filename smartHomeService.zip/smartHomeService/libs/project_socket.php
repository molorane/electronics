<?php

class project_socket{

	private $host = 'localhost';
	private $port = 5000;
	private $sock;
	private $reply;

	public function __construct(){
		try{
			$this->sock = socket_create(AF_INET, SOCK_STREAM, 0);
			socket_connect($this->sock, $this->host, $this->port);
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	public function sendCommand($msg){
		try{
			socket_write($this->sock, $msg, strlen($msg));
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	public function getResponse(){
		try{
			$response = socket_read($this->sock, 1024);
			$this->reply = trim($response);
			return $this->reply;
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	public function close_socket(){
		socket_close($this->sock);
	}
}