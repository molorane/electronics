<?php

// PASSWORD HASH KEY
define('PASSWORD_HASH_KEY','blessing');

// GENERAL HASH KEY
define('GENERAL_HASH_KEY','botle');
