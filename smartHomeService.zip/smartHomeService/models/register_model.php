<?php

class register_model extends model{

	public function __construct(){
		parent::__construct();
	}

	public function register($txtUsername,$txtFirstName,$txtLastName,$txtEmail,$txtTelephone,
									$pswPassword,$pswPasswordConfirm){		
		try{
			if(isset($txtUsername) && isset($txtFirstName) && isset($txtLastName) && isset($txtEmail) && 
				isset($txtTelephone) && isset($pswPassword) && isset($pswPasswordConfirm)){
					
				if($pswPassword == $pswPasswordConfirm){
					
					$chkIsAproved = 1;
					$chkIsLocked = 1;
					$ddlRole = 28; // Default user type is guest
					$cCode = self::generateRandomString();
					$Password_hashed = hash::create('md5', $pswPassword, PASSWORD_HASH_KEY);
					
					$query = "CALL newAccount(:UserName,:Email,:Password,:IsApproved,:IsLocked,:RoleID,:cCode)";

					$sth = $this->conn->prepare($query);
					$sth->bindParam(':UserName', $txtUsername, PDO::PARAM_STR);
					$sth->bindParam(':Email', $txtEmail, PDO::PARAM_STR);
					$sth->bindParam(':Password', $Password_hashed, PDO::PARAM_STR);
					$sth->bindParam(':IsLocked', $chkIsLocked, PDO::PARAM_INT);
					$sth->bindParam(':IsApproved', $chkIsAproved, PDO::PARAM_INT);
					$sth->bindParam(':RoleID', $ddlRole, PDO::PARAM_INT);
					$sth->bindParam(':cCode', $cCode, PDO::PARAM_STR);
					$sth->execute();
					
					if($sth->rowCount() > 0){
						
						$query = "CALL newUser(:UserName,:Surname,:FirstName)";
						$sth = $this->conn->prepare($query);
						$sth->bindParam(':UserName', $txtUsername, PDO::PARAM_STR);
						$sth->bindParam(':Surname', $txtLastName, PDO::PARAM_STR);
						$sth->bindParam(':FirstName', $txtFirstName, PDO::PARAM_STR);
						$sth->execute();
						
						if($sth->rowCount() > 0){
							$message = "Congradulations, an account for you has been successfully created by an admin. 
							UserName: {$txtUsername} Your activation code :<b>{$cCode}</b>, can be used to activate your account!";
					
							$sendMail = new sendmail("New Account");
							$sendMail->sendGeneralToEmail("Account created" ,
														"Smart Home" ,
														$message,
														$txtEmail);					
							self::GenericResponse(1,"Congradulations, account created! 
													But you need an administrator to approve the account.
													You will only be logged in after approval!");
						}else{
							self::GenericResponse(0,"Personal information for new user could not be created!");
						}
					}else{
						self::GenericResponse(0,"Login details for new user could not be created!");
					}
					
				}else{
					self::GenericResponse(0,"The server says: Passwords do not match!");
				}
			}else{
				self::GenericResponse(0,"The server says: Fields are not all filled!");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"Register: ".$e->getMessage());
		}
	}
}
