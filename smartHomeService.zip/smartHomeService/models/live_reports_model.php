<?php

class live_reports_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	function getLiveAmpsDB(){
		try{
			$query = "SELECT liveID, liveTime, liveValue, liveRaw
							FROM tbl_liveamps
							ORDER BY liveID DESC
							LIMIT 1";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			$data = $sth->fetchAll();
			
			if(!empty($data[0]['liveID'])){
				$response["success"] = 1;
				$response["liveTime"] = $data[0]['liveTime'];
				$response["liveValue"] = $data[0]['liveValue'];
				$response["liveRaw"] = $data[0]['liveRaw'];
				$response["expValue"] = self::getExpectedConsumption(); 
				return json_encode($response);
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"getLiveAmpsDB: ".$e->getMessage());
		}
	}
	
	// return expected consumption
	function getExpectedConsumption(){
		try{
			$query = "SELECT value FROM tbl_settings WHERE stID = 1";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			$data = $sth->fetchAll();
			
			if(!empty($data[0]['value'])){
				return $data[0]['value'];
			}
			return 0;
		}catch(PDOException $e){
		    self::GenericResponse(0,"getExpectedConsumption: ".$e->getMessage());
		}
	}
}
