<?php

class appliances_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	// appliance categories
	function applianceCategories(){
		try{
			$sql = 'CALL applianceCategories()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"applianceCategoriesProc: ".$e->getMessage());
		}
	}
	
	// Get all devices with device_id =device_id 
	function AllDevices($device_id){
		$connected_device = new connected_device();
		return $connected_device->AllDevices($device_id);
	}
	
	
	function GetAppliance($app_id){
		$appliance = new appliance($app_id);
		return $appliance->GetAppliance();
	}
	
	function isPIR($pir_id){
		try{
			$sql = 'CALL isPIR(:pir_id)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':pir_id', $pir_id);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"isPIRProc: ".$e->getMessage());
		}
	}
	
	function allConnectedBulbs(){
		try{
			$sql = 'CALL allConnectedBulbs()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"allConnectedBulbsProc: ".$e->getMessage());
		}
	}
	
	function allPIRBulbs($pir_id){
		try{
			$sql = 'CALL allPIRBulbs(:pir_id)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':pir_id', $pir_id);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"allPIRBulbsProc: ".$e->getMessage());
		}
	}
	
	function addPIRBulb($pir_id ,$conn_d_id){
		try{
			$query = "INSERT INTO tbl_motionlights(pirID,conn_d_id)
								VALUES (:pirID,:conn_d_id)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':pirID', $pir_id, PDO::PARAM_INT);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->execute();
			
			if($sth->rowCount() > 0){
				self::GenericResponse(1,"Bulb added to PIR event! 
										This means this bulb will light when PIR detects
										motion.");
			}else{
				self::GenericResponse(0,"No changes were made!");
			}
		}catch(PDOException $e){
			if($e->getCode() == '23000'){
				self::GenericResponse(0,"Sorry! You cannot add this bulb because it's already in the list.");
			}else{
				self::GenericResponse(0,"addPIRBulb: ".$e->getMessage());
			}
		}
	}
	
	function deletePIRBulb($conn_d_id, $pir_id){
		try{
			$query = "DELETE FROM tbl_motionlights
								WHERE pirID = :pirID
								AND conn_d_id = :conn_d_id";

			$sth = $this->conn->prepare($query);
			$sth->bindParam(':pirID', $pir_id, PDO::PARAM_INT);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->execute();
			
			if($sth->rowCount() > 0){
				self::GenericResponse(1,"Bulb removed from PIR event! 
										This means this bulb will not longer light when PIR detects
										motion.");
			}else{
				self::GenericResponse(0,"No changes were made!");
			}
		}catch(PDOException $e){
			if($e->getCode() == '23000'){
				self::GenericResponse(0,"Integrity constraint violation.  You cannot delete this device because it is being used by another section of the database.");
			}else{
				self::GenericResponse(0,"deletePIRBulb: ".$e->getMessage());
			}
		}
	}
}
