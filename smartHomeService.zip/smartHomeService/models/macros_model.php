<?php

class macros_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	//Get macrosDevices
	function macrosDevices(){
		$connected_device = new connected_device();
		return $connected_device->macrosDevices();
	}
	
	
	/**
     *  Macros Commands
	 *	macrosStatus
     * @param array(ints) $device_ids  list of all appliances to turn on.
     */
	
	function macrosTurnOn($UserName,$device_ids){
		try{
			
			$devices = "";
			foreach($device_ids as $device_id) {
				$devices .= $device_id."-";
			}
			$ondevices = substr($devices, 0, -1);
			
			$sendToPython = 'macros:on:'.$ondevices.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
			
			if($reply == 'success'){ // $reply == 'success'
				self::GenericResponse(1,"Success: command executed!");
			}else{
				self::GenericResponse(0,"Failure: command could not be executed! If you continue to experience this problem, please 
				consult with the system administrator. Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	function macrosTurnOff($UserName,$device_ids){
		try{
			$devices = "";
			$edited = false;
			foreach($device_ids as $device_id) {
				$devices .= $device_id."-";
			}
			$offdevices = substr($devices, 0, -1);
			
			// Message to turn status of a single device
			$sendToPython = 'macros:off:'.$offdevices.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
			
			if($reply == 'success'){ // $reply == 'success'			
				self::GenericResponse(1,"Success: command executed!");
			}else{
				self::GenericResponse(0,"Failure: command could not be executed! If you continue to experience this problem, please 
				consult with the system administrator. Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	function isOutSideLightsON(){
		try{
			$sql = 'CALL isOutSideLightsON()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"isOutSideLightsONProc: ".$e->getMessage());
		}
	}
	
	function isInHouseLightsON(){
		try{
			$sql = 'CALL isInHouseLightsON()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"isInHouseLightsONProc: ".$e->getMessage());
		}
	}
	
	function OutSideLightsEvent($UserName,$chkStatus){
		try{
			$chkStatus = ($chkStatus == 'true')? 'on':'off';
			
			// Message to turn status of a single device
			$sendToPython = 'macrosCategory:OutSide:'.$chkStatus.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
			
			if($reply == 'success'){
				self::GenericResponse(1,"Outside lights ($chkStatus): command executed!");
			}else{
				self::GenericResponse(0,"Failure: command could not be executed! If you continue to experience this problem, please 
				consult with the system administrator. Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	function InHouseLightsEvent($UserName,$chkStatus){
		try{
			$chkStatus = ($chkStatus == 'true')? 'on':'off';
			
			// Message to turn status of a single device
			$sendToPython = 'macrosCategory:InHouse:'.$chkStatus.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
			
			if($reply == 'success'){		
				self::GenericResponse(1,"InHouse lights ($chkStatus): command executed!");
			}else{
				self::GenericResponse(0,"Failure: command could not be executed! If you continue to experience this problem, please 
				consult with the system administrator. Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	/**
	 *  Macros Custom
	 *	section
	 */
	function allMacros(){
		try{
			$sql = 'CALL allMacros()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"allMacros: ".$e->getMessage());
		}
	}
	
	function allCustomMacros(){
		try{
			$sql = 'CALL allCustomMacros()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"allCustomMacros: ".$e->getMessage());
		}
	}
	
	function getMacros($macID){
		try{
			$query = "CALL getMacros(:macID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':macID', $macID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getMacros: ".$e->getMessage());
		}
	}
	
	function addMacros($macName,$macDescription){
		if(isset($macName) && isset($macDescription)){
			try{
				$query = "INSERT INTO tbl_macros(macName,macDescription) VALUES(:macName,:macDescription)";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':macName', $macName, PDO::PARAM_STR);
				$sth->bindParam(':macDescription', $macDescription, PDO::PARAM_STR);
				$sth->execute();
				if($sth->rowCount() > 0){
					self::GenericResponse(1,"Macros command added!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"addMacros: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function editMacros($macID,$macName,$macDescription){
		
		if(isset($macID) && isset($macName) && isset($macDescription)){
			try{
				$query = "UPDATE tbl_macros
								 SET macName= :macName, macDescription = :macDescription
								 WHERE macID = :macID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':macID', $macID, PDO::PARAM_INT);
				$sth->bindParam(':macName', $macName, PDO::PARAM_STR);
				$sth->bindParam(':macDescription', $macDescription, PDO::PARAM_STR);
				$sth->execute();

				if($sth->rowCount() > 0){
					self::GenericResponse(1,"Macros command updated!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"editMacros: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function deleteMacros($macID){
		if(isset($macID)){
			try{
				$query = "DELETE FROM tbl_macros
									WHERE macID = :macID";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':macID', $macID, PDO::PARAM_INT);
				$sth->execute();
				if( $sth->rowCount() > 0){
					self::GenericResponse(1,"Macros command deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"deleteMacros: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function allDevices(){
		try{
			$sql = 'CALL allDevices()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"allDevices: ".$e->getMessage());
		}
	}
	
	function allMacrosList($macID){
		try{
			$query = "CALL allMacrosList(:macID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':macID', $macID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"allMacrosList: ".$e->getMessage());
		}
	}
	
	function addMacrosDevice($macID,$conn_d_id){
		if(isset($macID) && isset($conn_d_id)){
			try{
				$query = "INSERT INTO tbl_macros_list(macID,conn_d_id)
								 VALUES(:macID,:conn_d_id)";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':macID', $macID, PDO::PARAM_INT);
				$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
				$sth->execute();

				if($sth->rowCount() > 0){
					self::GenericResponse(1,"Macros device added!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"editMacros: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function removeMacrosDevice($macID,$conn_d_id){
		if(isset($macID) && isset($conn_d_id)){
			try{
				$query = "DELETE FROM tbl_macros_list
									WHERE macID = :macID AND conn_d_id = :conn_d_id";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':macID', $macID, PDO::PARAM_INT);
				$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
				$sth->execute();
				if( $sth->rowCount() > 0){
					self::GenericResponse(1,"Macros device command remove!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"removeMacrosDevice: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function customTurnOn($UserName,$macID,$state){
		try{
			// Message to turn status of a single device
			$sendToPython = 'macrosCustom:'.$macID.':'.$state.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
			
			if($reply == 'success'){		
				self::GenericResponse(1,"Operation successful.");
			}else{
				self::GenericResponse(0,"Failure: command could not be executed! If you continue to experience this problem, please 
				consult with the system administrator. Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	function customTurnOff($UserName,$macID,$state){
		try{
			// Message to turn status of a single device
			$sendToPython = 'macrosCustom:'.$macID.':'.$state.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
			
			if($reply == 'success'){		
				self::GenericResponse(1,"Operation successful.");
			}else{
				self::GenericResponse(0,"Failure: command could not be executed! If you continue to experience this problem, please 
				consult with the system administrator. Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
}
