<?php


class profile_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	//Get Profile
	function getProfile($txtUsername){
		try{
			$query = "CALL getProfile(:userName)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':userName', $txtUsername, PDO::PARAM_STR);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetch());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getUserProfileProc: ".$e->getMessage());
		}
	}
	
	// Update Profile
	function updateProfile($txtUsername, $txtFirstName,$txtLastName){
		try{
			$sth=$this->conn->prepare("UPDATE tbl_user_info SET 
											surname = :surname,
											first_name = :first_name
											WHERE userName = :userName");
			$sth->bindParam(':userName', $txtUsername, PDO::PARAM_STR);
			$sth->bindParam(':surname', $txtFirstName, PDO::PARAM_STR);
			$sth->bindParam(':first_name', $txtLastName, PDO::PARAM_STR);
			$sth->execute();
			
			if($sth->rowCount() > 0){
				self::GenericResponse(1,"Update successful!");
			}else{
				self::GenericResponse(0,"No changes were made!");
			}
		}catch(PDOException $e){
			self::GenericResponse(0,$e->getMessage());
		}
	}
	
		// Update Password by student himself
	function changePassword($UserName, $OPassword,$NPassword, $CPassword){

		// Do validate at server side as well
		if(isset($UserName) && isset($OPassword) && isset($NPassword) && isset($CPassword)){

			if($NPassword == $CPassword){

				$newPassword = hash::create('md5',$NPassword,PASSWORD_HASH_KEY);
				$oldPassword = hash::create('md5',$OPassword,PASSWORD_HASH_KEY);

				try{
					$query = "SELECT userName
									FROM tbl_users
									WHERE userName = :userName AND Password = :Password";
					$sth = $this->conn->prepare($query);
					$sth->bindParam(':userName', $UserName);
					$sth->bindParam(':Password', $oldPassword, PDO::PARAM_STR);
					$sth->execute();
					$count =  $sth->rowCount();

					if($count > 0){
						$query = "UPDATE
									tbl_users SET Password = :Password
									WHERE userName = :userName";
						$sth = $this->conn->prepare($query);
						$sth->bindParam(':userName', $UserName);
						$sth->bindParam(':Password', $newPassword, PDO::PARAM_STR);
						$sth->execute();
						$count =  $sth->rowCount();

						if($count > 0){
							self::GenericResponse(1,"Password change successful!");
						}else{
							self::GenericResponse(0,"No changes were made!");
						}
					}else{
						self::GenericResponse(0,"The server says: old password is incorrect!");
					}
				}catch(PDOException $e){
				    self::GenericResponse(0,"changePassword: ".$e->getMessage());
				}
			}else{
				self::GenericResponse(0,"The server found that new password and confirm password do not match!");
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
