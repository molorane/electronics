<?php

class reports_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	//GetReportData
	function GetReportData($ddlCategory){
		try{
			if(isset($ddlCategory)){
				$sql = 'CALL getReport(:ddlCategory)';
				$sth = $this->conn->prepare($sql);
				$sth->bindParam(':ddlCategory', $ddlCategory, PDO::PARAM_STR);
				$sth->setFetchMode(PDO::FETCH_ASSOC);
				$sth->execute();
				return json_encode($sth->fetchAll());
			}
		}catch(PDOException $e){
		    echo "getReportProc: ".$e->getMessage();
		}
	}
}
