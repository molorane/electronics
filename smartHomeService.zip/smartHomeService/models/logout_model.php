<?php

class logout_model extends model{

	public function __construct(){
		parent::__construct();
	}
}
