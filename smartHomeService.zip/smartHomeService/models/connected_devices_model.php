<?php

class connected_devices_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	//Get AllConnectedDevices
	function AllConnectedDevices(){
		$connected_device = new connected_device();
		return $connected_device->AllConnectedDevices();
	}
	
	//Get ConnectedDevice
	function getConnectedDevice($conn_device_id){
		$connected_device = new connected_device($conn_device_id);
		return $connected_device->getConnectedDevice();
	}
	
	//Get DeviceActivity
	function getDeviceActivity($conn_device_id){
		try{
			$query = "CALL getDeviceActivity(:conn_d_id)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':conn_d_id', $conn_device_id, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getDeviceActivityProc: ".$e->getMessage());
		}
	}
	
	
	function loggTurnOn($UserName, $conn_d_id){
		try{
			$query = "INSERT INTO tbl_activity_log(turnonby, conn_d_id, modeID, raID)
						VALUES(:turnonby, :conn_d_id, 1, :raID)";
			
			$raID = $this->getkWh();
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':turnonby', $UserName, PDO::PARAM_STR);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->bindParam(':raID', $raID);
			$sth->execute();
		}catch(PDOException $e){
		    self::GenericResponse(0,"loggTurnOn: ".$e->getMessage());
		}
	}
	
	function loggTurnOff($UserName, $conn_d_id){
		try{
			$query = "SELECT loggID
							FROM tbl_activity_log
							WHERE conn_d_id = :conn_d_id
							ORDER BY loggID DESC
							LIMIT 1";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			$data = $sth->fetchAll();
			
			if(!empty($data[0]['loggID'])){
				
				$loggID = $data[0]['loggID'];
				$query = "UPDATE tbl_activity_log SET turnoff = NOW(), turnoffby = :turnoffby
						  WHERE loggID = :loggID";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':loggID', $loggID, PDO::PARAM_INT);
				$sth->bindParam(':turnoffby', $UserName, PDO::PARAM_STR);
				$sth->execute();
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"loggTurnOff: ".$e->getMessage());
		}
	}
	
	/*******************************************
		Get the recent electricity rate
		kWh
	********************************************/
	function getkWh(){
		try{
			$query = "SELECT raID,charge
							FROM tbl_rates
							ORDER BY raID DESC
							LIMIT 1";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			$data = $sth->fetchAll();
			return $data[0]['raID'];
		}catch(PDOException $e){
		    return "getkWh: ".$e->getMessage();
		}
	}
	
	// onStatusChange
	function onStatusChange($UserName,$conn_d_id, $dstatus){
		try{
			$status_value = ($dstatus == 'true')? 1:0;
			
			$device = json_decode($this->getConnectedDevice($conn_d_id),true);
			$device_type = $device['appliance'];
			
			// Message to turn state of a single device
			$sendToPython = 'state:'.$device_type.':'.$conn_d_id.':'.$status_value.':'.$UserName;
			$socket = new project_socket();
			$socket->sendCommand($sendToPython);
			$reply = $socket->getResponse();
							
			
			if($reply == 'success'){ // $reply == 'success'					
				self::GenericResponse(1,"Success: device state update!");
			}else{
				self::GenericResponse(0,"Failure: device state not updated! The problem seems to be on the server.
				If you continue to experience this problem, please consult the system administrator. 
				Call us on: 081715063");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,$e->getMessage());
		}
	}
	
	// onStatusChange
	function onModeChange($UserName, $conn_d_id, $device_type, $dmode){
		try{
			$mode = ($dmode == 'true')? 1:2;
			
			$query = "UPDATE tbl_connected_devices SET modeID = :modeID, auto_time_on = NULL, auto_time_off = NULL
							WHERE conn_d_id = :conn_d_id";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->bindParam(':modeID', $mode, PDO::PARAM_INT);
			$sth->execute();
			
			if($sth->rowCount() > 0){
				
				if($mode == 1){  
					
					$sendToPython = 'mode:'.$device_type.':'.$conn_d_id.':remove';
					$socket = new project_socket();
					$socket->sendCommand($sendToPython);
					$reply = $socket->getResponse();
					
					if($reply == 'success'){ // $reply == 'success'
						self::GenericResponse(1,"Success: device set to manual mode. 
											The system will no longer automatically turn on/off this device!");
					}else{
						self::GenericResponse(0,"Failure: device state not updated! The problem seems to be on the server.
											If you continue to experience this problem, please consult the system administrator. 
											Call us on: 081715063");
					}
				}else{
					self::GenericResponse(2,"Success: device to be set to automatic mode! 
											Please proceed to specify the time to turn on/off the device.
											For each selection you desire, click the set button after
											specifying the time.");
				}
			}else{
				self::GenericResponse(0,"No changes were made $mode!");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"onModeChange: ".$e->getMessage());
		}
	}
	
	// setAutoOnTime
	function setAutoOnTime($UserName, $conn_d_id,  $device_type, $auto_time){
		try{
			$query = "UPDATE tbl_connected_devices SET auto_time_on = :auto_time_on
							WHERE conn_d_id = :conn_d_id";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->bindParam(':auto_time_on', $auto_time);
			$sth->execute();
			
			if($sth->rowCount() > 0){
				$sendToPython = 'mode:'.$device_type.':'.$conn_d_id.':on';
				$socket = new project_socket();
				$socket->sendCommand($sendToPython);
				$reply = $socket->getResponse();
				
				if($reply == 'success'){
					self::GenericResponse(1,"Success: automatic-0n mode!");
				}else{
					self::GenericResponse(2,"Failure: automatic-on mode!");
				}
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"setAutoOnTime: ".$e->getMessage());
		}
	}
	
	// setAutoOffTime
	function setAutoOffTime($UserName, $conn_d_id,  $device_type, $auto_time){
		try{
			$query = "UPDATE tbl_connected_devices SET auto_time_off = :auto_time_off
							WHERE conn_d_id = :conn_d_id";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
			$sth->bindParam(':auto_time_off', $auto_time);
			$sth->execute();
			
			if($sth->rowCount() > 0){
				$sendToPython = 'mode:'.$device_type.':'.$conn_d_id.':off';
				$socket = new project_socket();
				$socket->sendCommand($sendToPython);
				$reply = $socket->getResponse();
				
				if($reply == 'success'){
					self::GenericResponse(1,"Success: automatic-off mode!");
				}else{
					self::GenericResponse(2,"Failure: automatic-off mode!");
				}
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"setAutoOffTime: ".$e->getMessage());
		}
	}
	
	// editConnectedDevice
	function editConnectedDevice($connDeviceID, $ddlAppliance, $ddlLevel, $ddlLocation,$txtDeviceName,$txtWatts){
		$connected_device = new connected_device();
		echo $connected_device->editConnectedDevice($connDeviceID, $ddlAppliance, $ddlLevel, $ddlLocation,$txtDeviceName,$txtWatts);
	}
	
	// editConnectedDevice
	function deleteAppliance($conn_d_id){
		$connected_device = new connected_device($conn_d_id);
		echo $connected_device->deleteAppliance();
	}
	
	// deleteDeviceLogg
	function deleteDeviceLog($loggID){
		if(isset($loggID)){
			try{
				$query = "DELETE FROM tbl_activity_log
									WHERE loggID = :loggID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':loggID', $loggID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Device log deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Integrity constraint violation.  You cannot delete this device because it is being used by another section of the database.");
				}else{
					self::GenericResponse(0,"deleteDeviceLog: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function emptyLog($conn_d_id){
		if(isset($conn_d_id)){
			try{
				$query = "DELETE FROM tbl_activity_log
									WHERE conn_d_id = :conn_d_id";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':conn_d_id', $conn_d_id, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Device log emptied!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Integrity constraint violation.  You cannot delete this device because it is being used by another section of the database.");
				}else{
					self::GenericResponse(0,"emptyLog: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
