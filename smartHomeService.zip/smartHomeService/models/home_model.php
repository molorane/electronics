<?php

class home_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	function getUsage($startDate, $endDate){
		try{
			$sql = 'CALL getElectricyCostWithRange(:startDate, :endDate)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':startDate', $startDate);
			$sth->bindParam(':endDate', $endDate);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"getElectricyCostWithRangeProc: ".$e->getMessage());
		}
	}
}
