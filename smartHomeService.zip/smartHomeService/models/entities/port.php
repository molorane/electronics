<?php

class port extends model{

	public $connPortID;
	public $connPort;

	public function __construct($_connPortID = NULL){
		parent::__construct();
		$this->connPortID = $_connPortID;
	}


	//Get Port
	function GetPort(){
		try{
			$query = "CALL getPort(:connPortID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':connPortID', $this->connPortID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getPortProc: ".$e->getMessage());
		}
	}

	//Get AllPorts
	function AllPorts(){
		try{
			$query = "CALL allPorts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"allPortsProc: ".$e->getMessage());
		}
	}
	
	
	/**
     * Similar to add Port except it only returns a single row
     *
     * @param  string $statement SQL query without user data
     * @param  mixed  ...$params Parameters
     * @return mixed
     * @throws \TypeError
     */
	 
	function AddPort($txtconnPort){

		if(isset($txtconnPort)){
			try{					 
				$connPort = str_replace(' ', '', $txtconnPort);
				$firstChars = substr($connPort,0,2);
				$lastChars = substr($connPort,2);
				
				if($lastChars <= 53){
				
					if($firstChars == "RP" || $firstChars == "AR"){
					
						$query = "INSERT INTO tbl_ports(connPort) VALUES(:connPort)";
						$this->conn->beginTransaction();
						$sth = $this->conn->prepare($query);
						$sth->bindParam(':connPort', $connPort, PDO::PARAM_STR);
						$sth->execute();

						$connPortID = $this->conn->lastInsertId();

						if($sth->rowCount() > 0){
							$this->conn->commit();
							self::GenericResponse(1,"Connection Port added! $lastChars",$connPortID);
						}else{
							$this->conn->rollback();
							self::GenericResponse(0,"No changes were made!");
						}
					}else{
						self::GenericResponse(0,"First two characters \"{$firstChars}\" are invalid. You should either have \"RP\" or \"AR\" as first two characters of your input string.");
					}
				}else{
					self::GenericResponse(0,"Connection port invalid. Connection ports starting with \"{$firstChars}\" cannot have a number higher than 53.");
				}
			}catch(PDOException $e){
				$this->conn->rollback();
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Duplicate entry. \"{$txtconnPort}\" already exist in the list of available ports. Please choose a different port!");
				}else{
					self::GenericResponse(0,"AddPort: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}


	//Edit Port
	function EditPort($txtconnPort){

		if(isset($this->connPortID) && isset($txtconnPort)){
			try{

				$query = "UPDATE tbl_ports SET connPort = :connPort
								 WHERE connPortID = :connPortID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':connPortID', $this->connPortID, PDO::PARAM_INT);
				$sth->bindParam(':connPort', $txtconnPort, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Connection Port edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"EditPort: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete Port
	function DeletePort(){

		if(isset($this->connPortID)){
			try{

				$query = "DELETE FROM tbl_ports
									WHERE connPortID = :connPortID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':connPortID', $this->connPortID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Connection Port deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"DeletePort: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
