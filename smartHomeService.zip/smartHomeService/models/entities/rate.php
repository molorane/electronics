<?php

class rate extends model{

	public $rateID;
	public $Charge;

	public function __construct($_raID = NULL){
		parent::__construct();
		$this->raID = $_raID;
	}

	//Get Rate
	function GetRate(){
		try{
			$query = "CALL getRate(:raID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':raID', $this->AppID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetRateProc: ".$e->getMessage());
		}
	}

	//Get AllRates
	function AllRates(){
		try{
			$query = "CALL allRates()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"AllRatesProc: ".$e->getMessage());
		}
	}
	
	//add Rate
	function AddRate($txtRate){

		if(isset($txtRate)){
			try{
				$query = "INSERT INTO tbl_rates(charge)
								 VALUES (:charge)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':charge', $txtRate);
				$sth->execute();

				$raID = $this->conn->lastInsertId();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Charge added!",$raID);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"AddRate: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//Edit Rate
	function EditRate($txtRate){

		if(isset($this->raID) && isset($txtRate)){
			try{
				$query = "UPDATE tbl_rates SET charge = :charge
								 WHERE raID = :raID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':raID', $this->raID, PDO::PARAM_INT);
				$sth->bindParam(':charge', $txtRate);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Rate edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"EditRate: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete Rate
	function DeleteRate(){

		if(isset($this->raID)){
			try{
				$query = "DELETE FROM tbl_rates
									WHERE raID = :raID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':raID', $this->raID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Rate deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"DeleteRate: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
