<?php

class role extends model{

	public $RoleID;
	public $RoleName;

	public function __construct($_RoleID = NULL){
		parent::__construct();
		$this->RoleID = $_RoleID;
	}


	//Get Role
	function GetRole(){
		try{
			$query = "CALL getRole(:RoleID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':RoleID', $this->RoleID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetRoleProc: ".$e->getMessage());
		}
	}

	//Get AllRoles
	function AllRoles(){
		try{
			$query = "CALL allRoles()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"allProc: ".$e->getMessage());
		}
	}

	//add Role
	function AddRole($txtRoleName){

		if(isset($txtRoleName)){
			try{
				$query = "INSERT INTO tbl_roles(roleName)
								 VALUES (:roleName)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':roleName', $txtRoleName, PDO::PARAM_STR);
				$sth->execute();

				$RoleID = $this->conn->lastInsertId();

				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Role added!",$RoleID);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
				if($e->getCode() == '23000'){
						self::GenericResponse(0,"Duplicate entry. $txtRoleName already exist.");
				}else{
					self::GenericResponse(0,"AddRole: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}


	//Edit Role
	function EditRole($txtRoleName){

		if(isset($this->RoleID) && isset($txtRoleName)){
			try{

				$query = "UPDATE tbl_roles SET roleName = :roleName
								 WHERE roleID = :roleID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':roleID', $this->RoleID, PDO::PARAM_INT);
				$sth->bindParam(':roleName', $txtRoleName, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Role edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"EditRole: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete Role
	function deleteRole(){

		if(isset($this->RoleID)){
			try{
				$query = "DELETE FROM tbl_roles
									WHERE roleID = :roleID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':roleID', $this->RoleID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Role deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"DeleteRole: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
