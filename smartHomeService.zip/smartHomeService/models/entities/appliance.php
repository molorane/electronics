<?php

class appliance extends model{

	public $AppID;
	public $Appliance;

	public function __construct($_AppID = NULL){
		parent::__construct();
		$this->AppID = $_AppID;
	}

	//Get appliance
	function GetAppliance(){
		try{
			$query = "CALL getAppliance(:AppID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':AppID', $this->AppID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetApplianceProc: ".$e->getMessage());
		}
	}

	//Get AllAppliances
	function AllAppliances(){
		try{
			$query = "CALL allAppliances()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"AllAppliancesProc: ".$e->getMessage());
		}
	}
	
	//Get GetUnUsedPorts
	function GetUnUsedPorts(){
		try{
			$query = "CALL GetUnUsedPorts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetUnUsedPortsProc: ".$e->getMessage());
		}
	}

	//add appliance
	function AddAppliance($txtAppliance){

		if(isset($txtAppliance)){
			try{
				$query = "INSERT INTO tbl_appliances(appliance)
								 VALUES (:appliance)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':appliance', $txtAppliance, PDO::PARAM_STR);
				$sth->execute();

				$AppID = $this->conn->lastInsertId();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Appliance added!",$AppID);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Duplicate entry. $txtAppliance already exist.");
				}else{
					self::GenericResponse(0,"AddAppliance: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//Edit appliance
	function EditAppliance($txtAppliance){

		if(isset($this->AppID) && isset($txtAppliance)){
			try{
				$query = "UPDATE tbl_appliances SET appliance = :appliance
								 WHERE appID = :appID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':appID', $this->AppID, PDO::PARAM_INT);
				$sth->bindParam(':appliance', $txtAppliance, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Appliance edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"EditAppliance: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete appliance
	function DeleteAppliance(){

		if(isset($this->AppID)){
			try{
				$query = "DELETE FROM tbl_appliances
									WHERE appID = :appID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':appID', $this->AppID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Appliance deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    if($e->getCode() == '23000'){
					self::GenericResponse(0,"Integrity constraint violation.  You cannot delete this appliance because it is being used by another section of the database.");
				}else{
					self::GenericResponse(0,"DeleteAppliance: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
