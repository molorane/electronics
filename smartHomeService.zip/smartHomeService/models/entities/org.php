<?php

class org extends model{

	public $orgID;
	public $orgName;
	public $ShortName;
	public $Telephone;
	public $Email;
	public $Enquiry;

	public function __construct($_orgID = NULL){
		parent::__construct();
		$this->orgID = $_orgID;
	}

	//Get Org
	public function GetOrg(){
		try{
			$query = "SELECT * FROM tbl_application";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return $sth->fetch();
		}catch(PDOException $e){
		    self::GenericResponse(0,"getOrg: ".$e->getMessage());
		}
	}
}
