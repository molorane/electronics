<?php

class account extends model{

	public $UserName;
	public $Email;
	public $IsApproved;
	public $IsLocked;
	public $CreateDate;
	public $AccountName;

	public function __construct($_UserName = NULL){
		parent::__construct();
		$this->UserName = $_UserName;
	}


	//Get Account
	function GetAccount(){
		try{
			$query = "CALL getAccount(:UserName)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':UserName', $this->UserName, PDO::PARAM_STR);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getAccountProc: ".$e->getMessage());
		}
	}

	//Get AllAccounts
	function AllAccounts(){
		try{
			$query = "CALL allAccounts()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"allAccountsProc: ".$e->getMessage());
		}
	}
	
	// AddUserAccount
	function AddUserAccount($ddlRole,$txtSurname,$txtFirstName,$txtEmail,$chkIsAproved,$chkIsLocked,$txtPassword,$txtConfirmPassword){

		if(isset($this->UserName) && isset($ddlRole) && isset($txtSurname) && isset($txtFirstName) && isset($txtEmail) && 
			isset($chkIsAproved) && isset($chkIsLocked) && isset($txtPassword) && isset($txtConfirmPassword)){
				
			if($txtPassword == $txtConfirmPassword){
				try{
					$chkIsAproved = ($chkIsAproved == 'true')? 1:0;
					$chkIsLocked = ($chkIsLocked == 'true')? 1:0;
					
					$cCode = self::generateRandomString();
					
					$Password_hashed = hash::create('md5', $txtPassword, PASSWORD_HASH_KEY);
					
					$query = "CALL newAccount(:UserName,:Email,:Password,:IsApproved,:IsLocked,:RoleID,:cCode)";

					$sth = $this->conn->prepare($query);
					$sth->bindParam(':UserName', $this->UserName, PDO::PARAM_STR);
					$sth->bindParam(':Email', $txtEmail, PDO::PARAM_STR);
					$sth->bindParam(':Password', $Password_hashed, PDO::PARAM_STR);
					$sth->bindParam(':IsLocked', $chkIsLocked, PDO::PARAM_INT);
					$sth->bindParam(':IsApproved', $chkIsAproved, PDO::PARAM_INT);
					$sth->bindParam(':RoleID', $ddlRole, PDO::PARAM_INT);
					$sth->bindParam(':cCode', $cCode, PDO::PARAM_STR);
					$sth->execute();

					if($sth->rowCount() > 0){
						
						$firstExe = $this->conn;
						
						$query = "CALL newUser(:UserName,:Surname,:FirstName)";

						$sth = $this->conn->prepare($query);
						$sth->bindParam(':UserName', $this->UserName, PDO::PARAM_STR);
						$sth->bindParam(':Surname', $txtSurname, PDO::PARAM_STR);
						$sth->bindParam(':FirstName', $txtFirstName, PDO::PARAM_STR);
						$sth->execute();
						
						if($sth->rowCount() > 0){
							$message = "Congradulations, an account for you has been successfully created by an admin. 
							UserName: {$this->UserName} Your activation code :<b>{$cCode}</b>, can be used to activate your account!";
					
							$sendMail = new sendmail("New Account");
							$sendMail->sendGeneralToEmail("Account created" ,
														"Smart Home" ,
														$message,
														$txtEmail);
														
							self::GenericResponse(1,"Account created!");
						}else{
							self::GenericResponse(0,"Personal information for new user could not be created!");
						}
					}else{
						self::GenericResponse(0,"Login details for new user could not be created!");
					}
				}catch(PDOException $e){
					self::GenericResponse(0,"AddAccount: ".$e->getMessage());
				}
			}else{
				self::GenericResponse(0,"The server says: Passwords do not match!");
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
		//edit User Account
	function editUserAccount($ddlRole,$txtEmail,$chkIsAproved,$chkIsLocked){

		if(isset($this->UserName) && isset($ddlRole) && isset($txtEmail) && 
			isset($chkIsAproved) && isset($chkIsLocked)){
			try{
				$chkIsAproved = ($chkIsAproved == 'true')? 1:0;
				$chkIsLocked = ($chkIsLocked == 'true')? 1:0;
				
				$query = "UPDATE tbl_users
								SET Email = :Email, roleID = :roleID,
								IsLocked = :IsLocked, IsApproved = :IsApproved
								WHERE userName = :userName";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':userName', $this->UserName, PDO::PARAM_STR);
				$sth->bindParam(':Email', $txtEmail, PDO::PARAM_STR);
				$sth->bindParam(':roleID', $ddlRole, PDO::PARAM_INT);
				$sth->bindParam(':IsLocked', $chkIsLocked, PDO::PARAM_INT);
				$sth->bindParam(':IsApproved', $chkIsAproved, PDO::PARAM_INT);
				$sth->execute();

				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account updated!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
				if($e->getCode() == '23000'){
						self::GenericResponse(0,"Duplicate entry.");
				}else{
					self::GenericResponse(0,"editUserAccount: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//add Account
	function AddAccount($txtUserName,$txtEmail,$txtPassword,$txtRoleID,$txtOTP){

		if(isset($txtAccountName)){
			try{
				$query = "INSERT INTO tbl_users(userName,Email,Password,roleID,cCode)
								 VALUES (:userName,:Email,:Password,:roleID,:cCode)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':userName', $txtUserName, PDO::PARAM_STR);
				$sth->bindParam(':Email', $txtEmail, PDO::PARAM_STR);
				$sth->bindParam(':Password', $txtPassword, PDO::PARAM_STR);
				$sth->bindParam(':roleID', $txtRoleID, PDO::PARAM_STR);
				$sth->bindParam(':cCode', $txtOTP, PDO::PARAM_STR);
				$sth->execute();

				$UserName = $this->conn->lastInsertId();

				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account added!",$UserName);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
				self::GenericResponse(0,"AddAccount: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}


	//Edit Account
	function EditAccount($txtEmail,$txtPassword,$txtRoleID){

		if(isset($this->UserName) && isset($txtEmail) && isset($txtPassword) && isset($txtRoleID)){
			try{

				$query = "UPDATE tbl_users SET Email =:Email, Password = :Password, roleID = :roleID
								 WHERE userName = :userName";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':userName', $this->UserName, PDO::PARAM_STR);
				$sth->bindParam(':Email', $txtEmail, PDO::PARAM_STR);
				$sth->bindParam(':Password', $txtPassword, PDO::PARAM_STR);
				$sth->bindParam(':roleID', $txtRoleID, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"EditAccount: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	//Edit Account Email
	function EditAccountEmail($txtEmail){

		if(isset($this->UserName) && isset($txtEmail)){
			try{

				$query = "UPDATE tbl_users SET Email =:Email
								 WHERE UserName = :UserName";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':UserName', $this->UserName, PDO::PARAM_STR);
				$sth->bindParam(':Email', $txtEmail, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"EditAccountEmail: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	//Edit Account Password
	function EditAccountPassword($txtPassword){

		if(isset($this->UserName) && isset($txtPassword)){
			try{

				$query = "UPDATE tbl_users SET Password = :Password
								 WHERE userName = :userName";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':userName', $this->UserName, PDO::PARAM_STR);
				$sth->bindParam(':Password', $txtPassword, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"EditAccountPassword: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	//Edit Account Role
	function EditAccountRole($txtRoleID){

		if(isset($this->UserName) && isset($txtRoleID)){
			try{
				$query = "UPDATE tbl_users SET roleID = :roleID
								 WHERE userName = :userName";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':userName', $this->UserName, PDO::PARAM_STR);
				$sth->bindParam(':roleID', $txtRoleID, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"EditAccountRole: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete Account
	function deleteAccount(){
		if(isset($this->UserName)){
			try{
				$query = "DELETE FROM tbl_users
									WHERE userName = :userName";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':userName', $this->UserName, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Account deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"deleteAccount: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
