<?php

class board extends model{

	public $connID;
	public $Board;

	public function __construct($_connID = NULL){
		parent::__construct();
		$this->connID = $_connID;
	}

	//Get Board
	function GetBoard(){
		try{
			$query = "SELECT connID,microController
									FROM tbl_board
					        WHERE connID = :connID";

			$sth = $this->conn->prepare($query);
			$sth->bindParam(':connID', $this->connID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();

			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetBoard: ".$e->getMessage());
		}
	}

	//Get AllBoard
	function AllBoard(){
		try{
			$query = "SELECT connID,microController
									FROM tbl_board";

			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();

			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"AllBoard: ".$e->getMessage());
		}
	}

	//add Board
	function AddBoard($txtBoard){

		if(isset($txtBoard)){
			try{
				$query = "INSERT INTO tbl_board(microController)
								 VALUES (:microController)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':microController', $txtBoard, PDO::PARAM_STR);
				$sth->execute();

				$connID = $this->conn->lastInsertId();

				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Board added!",$connID);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
				if($e->getCode() == '23000'){
						self::GenericResponse(0,"Duplicate entry. $txtBoard already exist.");
				}else{
					self::GenericResponse(0,"AddBoard: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}


	//Edit Board
	function EditBoard($txtBoard){

		if(isset($this->connID) && isset($txtBoard)){
			try{

				$query = "UPDATE tbl_board SET microController = :microController
								 WHERE connID = :connID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':connID', $this->connID, PDO::PARAM_INT);
				$sth->bindParam(':microController', $txtBoard, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Board edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"EditBoard: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete Board
	function deleteBoard(){

		if(isset($this->connID)){
			try{

				$query = "DELETE FROM tbl_board
									WHERE connID = :connID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':connID', $this->connID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Board deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}

			}catch(PDOException $e){
			    self::GenericResponse(0,"deleteBoard: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

}
