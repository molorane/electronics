<?php

class location extends model{

	public $locationID;
	public $location;

	public function __construct($_locationID = NULL){
		parent::__construct();
		$this->locationID = $_locationID;
	}

	//Get Location
	function GetLocation(){
		try{
			$query = "CALL GetLocation(:locationID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':locationID', $this->locationID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetLocationProc: ".$e->getMessage());
		}
	}

	//Get AllLocations
	function GetAllLocations(){
		try{
			$query = "CALL allLocations()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetAllLocationsProc: ".$e->getMessage());
		}
	}

	//add location
	function AddLocation($txtLocation){

		if(isset($txtLocation)){
			try{
				$query = "INSERT INTO tbl_location(location)
								 VALUES (:location)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':location', $txtLocation, PDO::PARAM_STR);
				$sth->execute();

				$locationID = $this->conn->lastInsertId();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Location added!",$locationID);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Duplicate entry. $txtLocation already exist.");
				}else{
					self::GenericResponse(0,"AddLocation: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//Edit appliance
	function EditLocation($txtLocation){

		if(isset($this->locationID) && isset($txtLocation)){
			try{
				$query = "UPDATE tbl_location SET location = :location
								 WHERE locationID = :locationID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':locationID', $this->AppID, PDO::PARAM_INT);
				$sth->bindParam(':location', $txtLocation, PDO::PARAM_STR);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Location edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"EditLocation: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete location
	function DeleteLocation(){

		if(isset($this->locationID)){
			try{
				$query = "DELETE FROM tbl_location
									WHERE locationID = :locationID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':locationID', $this->locationID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Location deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    if($e->getCode() == '23000'){
					self::GenericResponse(0,"Integrity constraint violation.  You cannot delete this location because it is being used by another section of the database.");
				}else{
					self::GenericResponse(0,"DeleteLocation: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
