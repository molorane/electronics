<?php

class connected_device extends model{

	public $conn_d_id;

	public function __construct($_conn_d_id = NULL){
		parent::__construct();
		$this->conn_d_id = $_conn_d_id;
	}


	//Get Connected Device
	function getConnectedDevice(){
		try{
			$query = "CALL getConnectedDevice(:conn_d_id)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':conn_d_id', $this->conn_d_id, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetch());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getConnectedDeviceProc: ".$e->getMessage());
		}
	}

	//Get AllConnectedDevice
	function AllConnectedDevices(){
		try{
			$query = "CALL allConnectedDevices()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"allConnectedDevicesProc: ".$e->getMessage());
		}
	}
	
	//Get macrosDevices
	function macrosDevices(){
		try{
			$query = "CALL macrosDevices()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"macrosDevicesProc: ".$e->getMessage());
		}
	}
	
	// Get all devices with device_id =device_id 
	function AllDevices($device_id){
		try{
			$query = "CALL allDevicesWithDeviceID(:device_id)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':device_id', $device_id, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"allDevicesWithDeviceIDProc: ".$e->getMessage());
		}
	}
	
	//new Device
	function newDevice($ddlAppliance,$ddlLevel,$ddlLocation,$txtDeviceName,$ddlConnPort,$txtWatts){

		if(isset($ddlAppliance) && isset($ddlLevel) && isset($ddlLocation) && isset($txtDeviceName) && isset($ddlConnPort) && isset($txtWatts)){
			try{
				
				$query = "SELECT * FROM tbl_ports WHERE connPortID = :connPortID";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':connPortID', $ddlConnPort, PDO::PARAM_STR);
				$sth->execute();
				
				if($sth->rowCount() > 0){
					
					$data = $sth->fetch();
					$connPort = $data['connPort'];
					
					$firstTwo = substr($connPort,0,2);
					$ddlBoard = ($firstTwo == "RP")? 2:1;
					$txtPIN = substr($connPort,2);
					
					if($firstTwo == "RP" || $firstTwo == "AR"){
							$query = "INSERT INTO tbl_connected_devices(appID,locationID,device_name,watts,connID,PIN,connPortID,levelID)
											 VALUES (:appID,:locationID,:device_name,:watts,:connID,:PIN,:connPortID,:levelID)";

							$sth = $this->conn->prepare($query);
							$sth->bindParam(':appID', $ddlAppliance, PDO::PARAM_INT);
							$sth->bindParam(':locationID', $ddlLocation, PDO::PARAM_INT);
							$sth->bindParam(':device_name', $txtDeviceName, PDO::PARAM_STR);
							$sth->bindParam(':watts', $txtWatts, PDO::PARAM_STR);
							$sth->bindParam(':connID', $ddlBoard, PDO::PARAM_INT);
							$sth->bindParam(':PIN', $txtPIN, PDO::PARAM_INT);
							$sth->bindParam(':connPortID', $ddlConnPort, PDO::PARAM_INT);
							$sth->bindParam(':levelID', $ddlLevel, PDO::PARAM_INT);
							$sth->execute();

							$AppID = $this->conn->lastInsertId();

							if($sth->rowCount() > 0){
								self::GenericResponse(1,"Device added!",$AppID);
							}else{
								self::GenericResponse(0,"No changes were made!");
							}
					}else{
						self::GenericResponse(0,"Invalid first two characters \"{$firstTwo}\" of the connection point.
												Connection point numbers starts with either \"RP\" or \"AR\"");
					}
				}else{
					self::GenericResponse(0,"The connection port \"{$ddlConnPort}\" you specified is not available in the list of available ports.");
				}
			}catch(PDOException $e){
			self::GenericResponse(0,"newDevice".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	// editConnectedDevice
	function editConnectedDevice($connDeviceID, $ddlAppliance, $ddlLevel, $ddlLocation,$txtDeviceName,$txtWatts){

		if(isset($connDeviceID) && isset($ddlAppliance) &&   isset($ddlLevel) &&  isset($ddlLocation) && isset($txtDeviceName) && isset($txtWatts)){
			try{
				$query = "UPDATE tbl_connected_devices
								 SET appID = :appID, levelID= :levelID, locationID = :locationID, device_name = :device_name,watts = :watts
								 WHERE conn_d_id = :conn_d_id";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':conn_d_id', $connDeviceID, PDO::PARAM_INT);
				$sth->bindParam(':appID', $ddlAppliance, PDO::PARAM_INT);
				$sth->bindParam(':locationID', $ddlLocation, PDO::PARAM_INT);
				$sth->bindParam(':levelID', $ddlLevel, PDO::PARAM_INT);
				$sth->bindParam(':device_name', $txtDeviceName, PDO::PARAM_STR);
				$sth->bindParam(':watts', $txtWatts, PDO::PARAM_STR);
				$sth->execute();

				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Device updated!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Duplicate entry. You cannot have two devices connected to the same PIN on the same board!");
				}else{
					self::GenericResponse(0,"editConnectedDevice: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete appliance
	function deleteAppliance(){
		if(isset($this->conn_d_id)){
			try{
				$query = "DELETE FROM tbl_connected_devices
									WHERE conn_d_id = :conn_d_id";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':conn_d_id', $this->conn_d_id, PDO::PARAM_INT);
				$sth->execute();
				if( $sth->rowCount() > 0){
					self::GenericResponse(1,"appliance deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				if($e->getCode() == '23000'){
					self::GenericResponse(0,"Integrity constraint violation.  You cannot delete this device because it is being used by another section of the database.");
				}else{
					self::GenericResponse(0,"deleteAppliance: ".$e->getMessage());
				}
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
