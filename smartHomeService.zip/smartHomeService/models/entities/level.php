<?php

class level extends model{

	public $levelID;
	public $level;

	public function __construct($_levelID = NULL){
		parent::__construct();
		$this->levelID = $_levelID;
	}

	//Get Level
	function GetLevel(){
		try{
			$query = "CALL getLevel(:levelID)";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':levelID', $this->AppID, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetLevelProc: ".$e->getMessage());
		}
	}

	//Get AllLevels
	function AllLevels(){
		try{
			$query = "CALL allLevels()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"AllLevelsProc: ".$e->getMessage());
		}
	}
	
	//add Level
	function AddLevel($txtLevel){

		if(isset($txtLevel)){
			try{
				$query = "INSERT INTO tbl_level(level)
								 VALUES (:level)";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':level', $txtLevel);
				$sth->execute();

				$levelID = $this->conn->lastInsertId();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Level added!",$levelID);
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"AddLevel: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//Edit Level
	function EditLevel($txtLevel){

		if(isset($this->levelID) && isset($txtLevel)){
			try{
				$query = "UPDATE tbl_level SET level = :level
								 WHERE levelID = :levelID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':levelID', $this->levelID, PDO::PARAM_INT);
				$sth->bindParam(':level', $txtLevel);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Level edited!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"EditLevel: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}

	//delete Level
	function DeleteLevel(){

		if(isset($this->levelID)){
			try{
				$query = "DELETE FROM tbl_level
									WHERE levelID = :levelID";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':levelID', $this->levelID, PDO::PARAM_INT);
				$sth->execute();
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"Level deleted!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
			    self::GenericResponse(0,"DeleteLevel: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
}
