<?php

class settings_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	
	/*****************************************************************
		Appliance Section
	******************************************************************/
	
	// Add Appliance
	function AddAppliance($txtAppliance){
		$appliance = new appliance();
		echo $appliance->AddAppliance($txtAppliance);
	}
	
	// Edit Appliance
	function EditAppliance($AppID,$txtAppliance){
		$appliance = new appliance($AppID);
		echo $appliance->EditAppliance($txtAppliance);
	}
	
	// Delete Appliance
	function DeleteAppliance($Appliance_code){
		$appliance = new appliance($Appliance_code);
		echo $appliance->DeleteAppliance();
	}
	
	//Get AllAppliances
	function AllAppliances(){
		$appliance = new appliance();
		return $appliance->AllAppliances();
	}
	
	function GetAllLocations(){
		$location = new location();
		return $location->GetAllLocations();
	}
	
	//Get GetUnUsedPorts
	function GetUnUsedPorts(){
		$appliance = new appliance();
		return $appliance->GetUnUsedPorts();
	}
	
	/*****************************************************************
		Connected Devices Section
	******************************************************************/
	
	// new Device
	function newDevice($ddlAppliance,$ddlLevel,$ddlLocation,$txtDeviceName,$ddlConnPort,$txtWatts){
		$connected_device = new connected_device();
		echo $connected_device->newDevice($ddlAppliance,$ddlLevel,$ddlLocation,$txtDeviceName,$ddlConnPort,$txtWatts);
	}
	
	/*****************************************************************
		Roles Section
	******************************************************************/
	
	// Add Role
	function AddRole($txtRole){
		$role = new role();
		echo $role->Addrole($txtRole);
	}
	
	// Edit Role
	function EditRole($AppID,$txtRole){
		$role = new role($AppID);
		echo $role->EditRole($txtRole);
	}
	
	// Delete Role
	function DeleteRole($AppID){
		$role = new role($AppID);
		echo $role->DeleteRole();
	}
	
	//Get AllRoles
	function AllRoles(){
		$role = new role();
		return $role->AllRoles();
	}
	
	
	/*****************************************************************
		Accounts Section
	******************************************************************/
	
	// Add Account
	function AddAccount($txtUserName,$txtEmail,$txtPassword,$txtRoleID,$txtOTP){
		$Account = new account();
		echo $Account->AddAccount($txtUserName,$txtEmail,$txtPassword,$txtRoleID,$txtOTP);
	}
	
	// Edit Account
	function EditAccount($txtEmail,$txtPassword,$txtRoleID){
		$Account = new account($AppID);
		echo $Account->EditAccount($txtEmail,$txtPassword,$txtRoleID);
	}
	
	// Edit Account Email
	function EditAccountEmail($txtEmail){
		$Account = new account($AppID);
		echo $Account->EditAccountEmail($txtEmail);
	}
	
	// Edit Account Password
	function EditAccountPassword($txtPassword){
		$Account = new account($AppID);
		echo $Account->EditAccountPassword($txtPassword);
	}
	
	// Edit Account Role
	function EditAccountRole($txtRoleID){
		$Account = new account($AppID);
		echo $Account->EditAccountRole($txtRoleID);
	}
	
	// Delete Account
	function DeleteAccount($AppID){
		$Account = new account($AppID);
		echo $Account->DeleteAccount();
	}
	
	//Get AllAccounts
	function AllAccounts(){
		$Account = new account();
		return $Account->AllAccounts();
	}
	
	/*
	========================================
	Admin
	========================================
	*/
	
	//getUserAccount
	function getUserAccount($UserName){
		$Account = new account($UserName);
		echo $Account->GetAccount();
	}
	
	//editUserAccount
	function editUserAccount($txtUserName,$ddlRole,$txtEmail,$chkIsAproved,$chkIsLocked){
		$Account = new account($txtUserName);
		echo $Account->editUserAccount($ddlRole,$txtEmail,$chkIsAproved,$chkIsLocked);
	}
	
	//AddUserAccount
	function AddUserAccount($txtUserName,$ddlRole,$txtSurname,$txtFirstName,$txtEmail,$chkIsAproved,$chkIsLocked,$txtPassword,$txtConfirmPassword){
		$Account = new account($txtUserName);
		echo $Account->AddUserAccount($ddlRole,$txtSurname,$txtFirstName,$txtEmail,$chkIsAproved,$chkIsLocked,$txtPassword,$txtConfirmPassword);
	}
	
	/*****************************************************************
		Roles Section
	******************************************************************/
	
	// Add Role
	function AddPort($txtRole){
		$port = new port();
		echo $port->AddPort($txtRole);
	}
	
	// Edit Role
	function EditPort($AppID,$txtPort){
		$port = new port($AppID);
		echo $port->EditPort($txtPort);
	}
	
	// Delete Port
	function DeletePort($AppID){
		$port = new port($AppID);
		echo $port->DeletePort();
	}
	
	//Get AllPorts
	function AllPorts(){
		$port = new port();
		return $port->AllPorts();
	}
	
	
	/*****************************************************************
		General Settings Section
	******************************************************************/
	
	//Get Settings
	function GetSettings(){
		try{
			$query = "CALL getSettings()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"getSettingsProc: ".$e->getMessage());
		}
	}
	
	// saveSettings
	function saveSettings($txtConsumption,$txtEmail, $emailOnConsumption, $emailOnAlarm, $txtPhone, $phoneOnConsumption,
									$phoneOnAlarm, $txtDailyConsumption, $txtWeeklyConsumption, $txtMonthlyConsumption, $dailyActivities){
										
		if(isset($txtConsumption) && isset($txtEmail) &&  isset($emailOnConsumption) && isset($emailOnAlarm) && isset($txtPhone)
			&& isset($phoneOnConsumption) && isset($phoneOnAlarm) &&  isset($txtDailyConsumption) && isset($txtWeeklyConsumption) 
			&& isset($txtMonthlyConsumption) && isset($dailyActivities)){
				
				self::updateSettings(1,$txtConsumption);
				self::updateSettings(2,$txtEmail);
				self::updateSettings(3,$emailOnConsumption);
				self::updateSettings(4,$emailOnAlarm);
				self::updateSettings(5,$txtPhone);
				self::updateSettings(6,$phoneOnConsumption);
				self::updateSettings(7,$phoneOnAlarm);
				self::updateSettings(8,$txtDailyConsumption);
				self::updateSettings(9,$txtWeeklyConsumption);
				self::updateSettings(10,$txtMonthlyConsumption);
				self::updateSettings(11,$dailyActivities);
				
				self::GenericResponse(1,"Settings updated");
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	function updateSettings($st_id, $value){
		try{
			$query = "UPDATE tbl_settings
							 SET value = :value
							 WHERE stID = :stID";
			$sth = $this->conn->prepare($query);
			$sth->bindParam(':stID', $st_id, PDO::PARAM_INT);
			$sth->bindParam(':value', $value, PDO::PARAM_STR);
			$sth->execute();
		}catch(PDOException $e){
			self::GenericResponse(0,"updateSettings: ".$e->getMessage());
		}
	}
	
	
	/*****************************************************************
		Rates Section
	******************************************************************/
	
	// Add Rates
	function AddRate($txtRate){
		$rate = new rate();
		echo $rate->AddRate($txtRate);
	}
	
	// Edit Rate
	function EditRate($raID,$txtRate){
		$rate = new rate($raID);
		echo $rate->EditRate($txtRate);
	}
	
	// Delete Rate
	function DeleteRate($raID){
		$rate = new rate($raID);
		echo $rate->DeleteRate();
	}
	
	//Get AllRates
	function AllRates(){
		$rate = new rate();
		return $rate->AllRates();
	}
	
	
	/*****************************************************************
		Consumption Section - Electricity consumption
	******************************************************************/
	
	//Get Consumption
	function GetConsumption(){
		try{
			$query = "CALL getLiveAmps()";
			$sth = $this->conn->prepare($query);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
		    self::GenericResponse(0,"GetConsumption: ".$e->getMessage());
		}
	}
	
	/*****************************************************************
		Application Section
	******************************************************************/
	
	// saveApp
	function saveApp($txtAppName,$txtAppShortName, $txtDevelopedBy, $txtYearDeveloped){
										
		if(isset($txtAppName) && isset($txtAppShortName) &&  isset($txtDevelopedBy) && isset($txtYearDeveloped)){
				
			try{
				$query = "UPDATE tbl_application
								 SET appName = :appName,
								 appShortName = :appShortName,
								 developedBy = :developedBy,
								 yearDeveloped = :yearDeveloped";
				$sth = $this->conn->prepare($query);
				$sth->bindParam(':appName', $txtAppName, PDO::PARAM_STR);
				$sth->bindParam(':appShortName', $txtAppShortName, PDO::PARAM_STR);
				$sth->bindParam(':developedBy', $txtDevelopedBy, PDO::PARAM_STR);
				$sth->bindParam(':yearDeveloped', $txtYearDeveloped, PDO::PARAM_INT);
				$sth->execute();
				
				$count =  $sth->rowCount();

				if($count > 0){
					self::GenericResponse(1,"App updated!");
				}else{
					self::GenericResponse(0,"No changes were made!");
				}
			}catch(PDOException $e){
				self::GenericResponse(0,"updateApp: ".$e->getMessage());
			}
		}else{
			self::GenericResponse(0,"The server says: Fields are not all filled!");
		}
	}
	
	
	/*****************************************************************
		Levels Section
	******************************************************************/
	
	// Add Level
	function AddLevel($txtLevel){
		$level = new level();
		echo $level->AddLevel($txtLevel);
	}
	
	// Edit Level
	function EditLevel($levelID,$txtLevel){
		$level = new level($levelID);
		echo $level->EditLevel($txtLevel);
	}
	
	// Delete Level
	function DeleteLevel($levelID){
		$level = new level($levelID);
		echo $level->DeleteLevel();
	}
	
	//Get AllLevels
	function AllLevels(){
		$level = new level();
		return $level->AllLevels();
	}
}
