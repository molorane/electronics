<?php

class alerts_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	function alertSeen($al_id){
		try{
			$sql = 'UPDATE tbl_alerts SET isSeen = 1 WHERE alID = ?';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(1, $al_id, PDO::PARAM_INT);
			$sth->execute();
		}catch(PDOException $e){
		    echo "alertSeen: ".$e->getMessage();
		}
	}
}
