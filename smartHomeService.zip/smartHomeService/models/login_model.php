<?php

class login_model extends model{

	public function __construct(){
		parent::__construct();
	}

	public function login($txtUsername,$pswPassword){		
		try{
			
			$password_hashed = hash::create('md5',$pswPassword,PASSWORD_HASH_KEY);
			
			$query = "SELECT u.userName
							FROM tbl_users u
							WHERE u.userName = :username";

			$sth = $this->conn->prepare($query);
			$sth->bindParam(':username', $txtUsername, PDO::PARAM_STR);
			$sth->execute();
			
			if($sth->rowCount() > 0){
			
				$query = "SELECT u.userName
								FROM tbl_users u
								WHERE u.IsLocked = 0 AND u.userName = :username";

				$sth = $this->conn->prepare($query);
				$sth->bindParam(':username', $txtUsername, PDO::PARAM_STR);
				$sth->execute();

				if($sth->rowCount() > 0){

						$query = "SELECT u.userName,r.roleName
											FROM tbl_users u
											JOIN tbl_roles r
											ON u.roleID = r.roleID
											WHERE (u.IsLocked = 0 AND u.userName = :username AND u.Password = :password)
											OR (u.IsLocked = 0 AND u.userName = :username AND u.Password = :password)";

						$sth = $this->conn->prepare($query);
						$sth->bindParam(':username', $txtUsername, PDO::PARAM_STR);
						$sth->bindParam(':password', $password_hashed , PDO::PARAM_STR);
						$sth->execute();
						$sth->setFetchMode(PDO::FETCH_ASSOC);

						if($sth->rowCount() > 0){
							self::GenericResponse(1,"Success");
						}else{
							self::GenericResponse(0,"Invalid credentials.");
						}
				}else{
					self::GenericResponse(0,"Account with username {$txtUsername} locked.");
				}
			}else{
				self::GenericResponse(0,"Account with username {$txtUsername} does not exist.");
			}
		}catch(PDOException $e){
		    self::GenericResponse(0,"Login run: ".$e->getMessage());
		}
	}
}
