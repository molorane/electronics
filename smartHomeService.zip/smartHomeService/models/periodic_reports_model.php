<?php

class periodic_reports_model extends model{

	public function __construct(){
		parent::__construct();
	}
	
	function todayElectricyCost(){
		try{
			$sql = 'CALL todayElectricyCost()';
			$sth = $this->conn->prepare($sql);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"todayElectricyCostProc: ".$e->getMessage());
		}
	}
	
	function weekElectricyCost($order){
		try{
			$sql = 'CALL weekElectricyCost(:order)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':order', $order, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"weekElectricyCostProc: ".$e->getMessage());
		}
	}
	
	function monthElectricyCost($order){
		try{
			$sql = 'CALL monthElectricyCost(:order)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':order', $order, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"monthElectricyCostProc: ".$e->getMessage());
		}
	}
	
	function quarterElectricyCost($order){
		try{
			$sql = 'CALL quarterElectricyCost(:order)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':order', $order, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"quarterElectricyCostProc: ".$e->getMessage());
		}
	}
	
	function yearlyElectricyCost($order){
		try{
			$sql = 'CALL yearlyElectricyCost(:order)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':order', $order, PDO::PARAM_INT);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"yearlyElectricyCostProc: ".$e->getMessage());
		}
	}
	
	function getElectricyCostWithRange($startDate, $endDate){
		try{
			$sql = 'CALL getElectricyCostWithRange(:startDate, :endDate)';
			$sth = $this->conn->prepare($sql);
			$sth->bindParam(':startDate', $startDate);
			$sth->bindParam(':endDate', $endDate);
			$sth->setFetchMode(PDO::FETCH_ASSOC);
			$sth->execute();
			return json_encode($sth->fetchAll());
		}catch(PDOException $e){
			self::GenericResponse(0,"getElectricyCostWithRangeProc: ".$e->getMessage());
		}
	}
}
