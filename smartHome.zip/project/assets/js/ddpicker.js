$('#date_picker').datetimepicker({
	format: 'dd/mm/yyyy',
	pickTime: false
});