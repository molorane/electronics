app.factory('smartService', function($http){
	
	return {
		getAllData: function(path){
			
			return $http.get(path).then(function (response){
				return Object.keys(response.data).map(e=>response.data[e]);
			});
			
		},		
		PNotify: function(success,message,title){
			if(success == 1){
				new PNotify({title: title,text: message,type: 'success'});
			}else{
				new PNotify({title: title,text: message,type: 'error'});
			}
		},
		TabbedNotification: function(success,message,title){
			if(success == 1){
				new TabbedNotification({title: title,text: message,type: 'success',sound: true})
			}else{
				new TabbedNotification({title: title,text: message,type: 'error',sound: true})
			}
		},
		tblSort: function(vm,keyname){
			vm.sortKey = keyname;   //set the sortKey to the param passed
			vm.reverse = !vm.reverse; //if true make it false and vice versa
		},
		imgShow: function (vm) {
			if(vm.device_type == 'Light Bulb'){
				vm.img = 'bulb.gif';
			}else if(vm.device_type == 'Air Conditioner'){
				vm.img = 'aircon.gif';
			}else if(vm.device_type == 'Garage Door'){
				vm.img = 'garage.gif';
			}else if(vm.device_type == 'Washing Machine'){
				vm.img = 'washing.gif';
			}else if(vm.device_type == 'Sprinkler'){
				vm.img = 'sprinkler.png';
			}else if(vm.device_type == 'Heater'){
				vm.img = 'heater.png';
			}else if(vm.device_type == 'Siren'){
				vm.img = 'siren.gif';
			}else if(vm.device_type == 'Gate'){
				vm.img = 'gate.gif';
			}else if(vm.device_type == 'Stove'){
				vm.img = 'stove.png';
			}else if(vm.device_type == 'Motion Detector'){
				vm.img = 'pir.png';
			}else if(vm.device_type == 'Door Sensor'){
				vm.img = 'doorSensor.png';
			}else if(vm.device_type == 'Fridge'){
				vm.img = 'fridge.png';
			}else if(vm.device_type == 'Geyser'){
				vm.img = 'geyser.png';
			}
		}
	};
	
});